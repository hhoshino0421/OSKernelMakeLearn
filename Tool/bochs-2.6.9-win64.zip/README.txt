Bochs x86 Emulator (Win64 build)
Version: 2.6.9

This package contains two Bochs executables (with and without debugger)
compiled for 64-bit Windows. An existing Bochs installation of the same version
is required.

See the home page of the Bochs project at http://bochs.sourceforge.net
